const { Router } = require('express');
const { Op, Character, Role } = require('../db');
const router = Router();

module.exports = router;